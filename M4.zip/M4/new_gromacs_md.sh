#!/bin/bash
/usr/local/gromacs/share/gromacs/top
<<com
echo -e "Prerequisites of running gromacs: \n Protein in .pdb file \n Ligand in .mol2 file \n charm forcefield 2021 \n cgneff python script \n perl script"
echo "Are all the prerequisites are there: y/n"
read r
echo -e "Ligand preparation:\n fix .mol2 file for ligand and sort through perl script"
echo "Provide the Ligand .mol2 file"
read lig

perl sort_mol2_bonds.pl $lig.mol2 $lig"_fix.mol2"

echo -e "Method for the ligand preparation :\n cgneff or \n swiss_pram"
read method
if [ $method == "cgneff" ];
then 
	echo "create .str file through cgneff server via fixed as: $lig.str"
	echo "is $lig.str generated: y/n"
	read res
  	if [ $res == "y" ];
  	then
		python3 cgenff_charmm2gmx_py3_nx2.py $lig $lig"_fix.mol2" $lig.str charmm36-jul2021.ff
	else 
		echo "Generate the .str file"
	fi
elif [ $method == "swiss_pram" ]; then
	echo "Changing $lig"_fix.mol2" to $lig.mol2"
	mv $lig"_fix.mol2" $lig.mol2
	echo "Plese use the swiss_parm server and generate the required files using $lig.mol2"
	
else 
	echo "Please check the typo error in method name: cgneff or swiss_pram"	
fi

echo "Is Ligand preparation Done via swiss_pram or cgneff?? :y/n"
read res1

echo "PROTEIN PREPARATION: choose 1, 1, 0, 0"
echo "Provide your protein name"
read protein
#if it wont work then go to swiss parm and upload mol2 file and get zip file which have .itp and other files for ligand
#process the protein and ignore the hydrogens to gro file (-ignh), using the charmm force feilds, charm modified TIP3P water model and NH3+ and COO- as the termini
 
gmx pdb2gmx -f $protein.pdb -o $protein"_processed.gro" -ter -ignh

#After that build the complex
# first convert the ligand into gro file from pdb having added hydrogens

echo "Converting Ligand pdb into .gro"
gmx editconf -f $lig.pdb -o $lig.gro

echo "Make the complex.gro by adding ligands coordinates from $lig.gro to $protein.gro and change the no. of atoms at second line"
touch complex.gro
echo "Is complex.gro ready??: y/n"
read res3
com
#add the coordinates of ligand from gro file to the protein gro file to make complex.gro file without spaces and also change the no. of atoms at the second line of complex.gro (how many atoms og ligand has been added, add those no. of atoms)

#then change the topology file topol.top by adding the ligand topology file (.itp) to it
# add UNK.itp file after the positional restrained file and before the water topology file in topol.top file
# add like the following in topol.top file
echo "Make the changes into topol.top file"
echo "add parameter file at top afer force field parameters as follows:"
echo -e "; Include ligand parametes\n #include ""$lig.itp"""
echo "Is ligand parametes are added into topol.top file: y/n"
read res4
echo "After that add ligand name at the end of topol.top file like follows"
echo "$lig                 1"
echo "Is ligand name added into topol.top file: y/n"
read res5

echo "SOLVATON:"
gmx editconf -f $protein"_processed.gro" -o newbox.gro -bt dodecahedron -d 1.0

gmx solvate -cp newbox.gro -cs spc216.gro -p topol.top -o solv.gro

echo "obtain the ions.mdp, em.mdp, nvt.mdp, nvt.mdp from gromacs site"

echo "Is all .mdp files available: y/n"
read res6

echo "IONS ADDITION: choose 15"
echo "Are you ready for ions additionecho: y/n"
read r3
gmx grompp -f ions.mdp -c solv.gro -p topol.top -o ions.tpr

gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname SOD -nname CLA -neutral

echo "MINIMIZATION:"
echo "Are You ready for minimization"
read r2

gmx grompp -f em.mdp -c solv_ions.gro -p topol.top -o em.tpr
gmx mdrun -v -deffnm em

echo "RESTRAING LIGAND: choose  0 & ! a H* then q"
echo "Are you ready for restraining ligand: y/n"
read r4
gmx make_ndx -f $lig.gro -o index_$lig.ndx
echo "Choose 3 and wright ok"
read r5
gmx genrestr -f $lig.gro -n index_$lig.ndx -o posre_$lig.itp -fc 1000 1000 1000

echo "add positional restrain file of ligand after the positional restrained file and before the water topology file in topol.top file as follows:"
echo -e "; Ligand position restraints \n #ifdef POSRES \n #include ""posre_$lig.itp"" \n #endif"
echo "Is position restraints added into topol.top file: y/n"
read res7

echo "Making tc-grps : choose 1 | 13 then 15 | 14 then q"
echo "Read above line, Are you ready for making tc-grps: y/n"
read r6
gmx make_ndx -f em.gro -o index.ndx

echo "chage tc-grps in all .mdp files as Protein_LIG Water_SOD"
echo "Change according to above, Is changes done in mdp files: y/n"
read res8

echo "EQILIBRIATION: Phase 1: NVT"
echo "Are you ready for NVT: y/n"
read r7
gmx grompp -f nvt.mdp -c em.gro -r em.gro -p topol.top -n index.ndx -o nvt.tpr

gmx mdrun -v -deffnm nvt

echo "EQILIBRIATION: Phase 2: NPT"
echo "Are you ready for NPT: y/n"
read r8
gmx grompp -f npt.mdp -c nvt.gro -t nvt.cpt -r nvt.gro -p topol.top -n index.ndx -o npt.tpr

gmx mdrun -v -deffnm npt

echo "PRODUCTION: change the no. of steps in md.mdp"
echo "Are you ready for final production run: y/n"
read res 9
gmx grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -n index.ndx -o md_$protein.tpr
gmx mdrun -v -deffnm md_$protein -nb gpu



